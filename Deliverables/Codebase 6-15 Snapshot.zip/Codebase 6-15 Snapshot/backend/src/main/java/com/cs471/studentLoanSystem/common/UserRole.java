package com.cs471.studentLoanSystem.common;

public enum UserRole {
    BANKOFFICER,
    STUDENT,
    REGISTRAR,
    LOANOFFICER
}
