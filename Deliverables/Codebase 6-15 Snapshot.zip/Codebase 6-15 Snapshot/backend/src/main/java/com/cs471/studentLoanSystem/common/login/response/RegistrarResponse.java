package com.cs471.studentLoanSystem.common.login.response;

public class RegistrarResponse extends LoginResponse {}
