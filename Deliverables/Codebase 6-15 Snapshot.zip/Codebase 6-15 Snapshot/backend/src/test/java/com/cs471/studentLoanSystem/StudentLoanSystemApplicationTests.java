package com.cs471.studentLoanSystem;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentLoanSystemApplicationTests {}
