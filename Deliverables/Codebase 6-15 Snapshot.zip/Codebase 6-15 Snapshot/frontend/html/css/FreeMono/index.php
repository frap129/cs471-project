<?php

// Common go-away script for directories where resources are pulled from via Web but user should not explore
header("Location: /");
exit;